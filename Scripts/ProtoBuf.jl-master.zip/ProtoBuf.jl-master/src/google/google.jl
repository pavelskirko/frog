module GoogleProtoBuf
    include("descriptor_pb.jl")
end
module GoogleProtoBufCompiler
    include("plugin_pb.jl")
end
