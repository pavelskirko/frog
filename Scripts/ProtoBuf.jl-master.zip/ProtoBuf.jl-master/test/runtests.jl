using Test

include("testtypevers.jl")
include("testutilapi.jl")
include("testwellknown.jl")
include("testcodec.jl")
include("services/testsvc.jl")
include("testprotoc.jl")
