sudo apt-get update -qq -y
sudo apt-get install protobuf-compiler
sudo apt-get install curl
sudo ./test/setup_protoc3.sh
